/*
icsd15046 Γεωργιος Δουμουρας
icsd15055 Αθανασιος Ζαρκαδας
*/

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import jdk.nashorn.internal.runtime.regexp.joni.Config;
// Κανει extend Jframe κα αντιστοιχει στο εξωτερικο παραθυρο των γραφικων
public class Main extends JFrame {
//Constructor
    public Main() {

        Board newBoard = new Board(); // Καλει την κλασση board για να δημιουργησει ενα καινουργιο
        System.out.println("\nDeck Created : "); // Μηνυμα επαληθευσης.

        setSize(1200, 800);// Διαστασεις εξωτερικου πανελ
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize(); // Κωδικας απο https://stackoverflow.com/
        this.setLocation(dim.width / 2 - this.getSize().width / 2, dim.height / 2 - this.getSize().height / 2); //Διαστασεις. κωδικας απο https://stackoverflow.com/
        //παραμετροποιω το παραθυρο
        setLayout(new BorderLayout());
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Αν πατησουμε X κλεινει.
        setTitle("Mah Jong"); //Τιτλος παραθυρου
        setVisible(true);
        NewPlayer(); // καλω την συναρτηση new player Που βρισκεται πιο κατω
        JMenuBar menu = new JMenuBar(); //δημιουργουμε μπαρα επιλογων.
        setJMenuBar(menu);

        //Redo Game για την επιλογηmenu  New game 
        JMenuItem newGame = new JMenuItem("New Game");
        newGame.addActionListener(new ActionListener() { //θετουμε action listener.
            public void actionPerformed(ActionEvent evt) {
                int confirm = JOptionPane.showConfirmDialog(null, // Μηνυμα για να μας πει ο χρηστης αν θελει να κανει καινουργιο παιχνιδι
                        "Do you want to Start a new Game?", // μηνθμα παραθυρου
                        "Message",
                        JOptionPane.YES_NO_OPTION); // δινουμε στο παραθυρο επιλογη ναι/οχι 
                if (confirm == 0) {
                    dispose();  // αφαιρουμε το προηγουμενο deck απο την μνημη
                    new Main(); // ξανατρεχουμε το προγραμμα . Στον χρηστη θα φαινεται σαν καινουργιο game.
                }
            }
        });
        menu.add(newGame); // το βαζουμε στο Jframe
// Παραμετροποιουμε την επιλογη about us στο Menu
        JMenuItem About = new JMenuItem("About Us");
        About.addActionListener(new ActionListener() { // παλι χρησιμοποιουμε action listener οπως ειναι αναγκαιο
            public void actionPerformed(ActionEvent evt) {
                int confirm = JOptionPane.showConfirmDialog(null, // εμφανιζουμε στο παραθυρο τα στοιχεια μας. 
                        "Γιώργος Δούμουρας Icsd15046"
                        + "\nΑθανάσιος Ζαρκάδας Icsd15055",
                        "About Us",
                        JOptionPane.CLOSED_OPTION); // η μονη επιλογη του παραθυρου ειναι το κλεισιμο/.
            }
        });
        menu.add(About); // το βαζουμε στο Jframe
//Παραμετροποιουμε τους κανονες οπως παραπανω καναμε για το about us
        JMenuItem Rules = new JMenuItem("Rules");
        Rules.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Κάθε ζευγάρι πλακιδίων πρέπει να συμμορφώνεται με τους ακόλουθους κανόνες:\n"
                        + "- Να μην υπάρχει άλλο πλακίδιο από πάνω του ή που να το καλύπτει εν μέρει\n"
                        + "- Να μην υπάρχει άλλο πλακίδιο που να βρίσκεται στα αριστερά ή στα δεξιά του"
                        + "\nΚάθε πλακίδιο εμφανίζεται τέσσερις φορές\n- Όταν αφαιρείτε ένα ζευγάρι\n προσπαθήστε να επιλέξετε με σύνεση, εάν έχετε 3 ελεύθερα πλακίδια του ίδιου τύπου\n -προσπαθείτε να δείτε μπροστά και να καταλάβετε ποια 2 πλακίδια θα είναι η καλύτερη επιλογή.",
                        "Rules",
                        JOptionPane.CLOSED_OPTION);
            }
        });
        menu.add(Rules); // το βαζουμε στο jframe
        add(newBoard, BorderLayout.CENTER);
    }
//Συναρτηση για τον καινουργιο παιχτη
    public void NewPlayer() {
        //Δημιουργια παιχτη με διαφορετικο thread για να μην σταματαει την λειτουργια απο πισω των γραφικων.
        Thread t = new Thread(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("New Player");
                String name = JOptionPane.showInputDialog(frame, "Please enter your name :");
                Player newPlayer = new Player(name); //Οτι μας δινει σαν ονομα το αντιστοιχουμε στην κλασση player που εχουμε υλοποιηση
                System.out.println("\n\nWelcome " + newPlayer.get_Name()); // με την get της κλασσης player αντιστοιχουμε το ονομα που μας εδωσε που ειναι τυπου Player και του εμφανιζουμε μηνυμα 
            }
        });
        t.start(); // Κωδικας για να δημιουργηθει το γραφικο

    }

    public static void main(String[] args) {

        /*
            Οταν τρεξετε την ασκηση μας σε περιπτωση που η εικονα ειναι ασπρη μικρινετε το παραθυρο του 
            παιχνιδιου και θα πρεπει να εμφανιστει οπως ειναι.
            Δεν καταφεραμε να υλοποιησουμε κατι περα απο το να εμφανισουμε ενα δειγμα μιας πιστας η οποια ομως δεν περιεχει το κλασσικο παιχνιδι με το να ειναι τα tiles το ενα πανω στο αλλο και να χρησιμοποιουμε μονο τα ελευθερα.
            προσπαθησαμε να κανουμε οτι καλυτερο γινοταν για αυτο η ασκηση ειναι ημιτελης. Ομως εχει τα βασικα γραφικα και λειτουργιες του παιχνιδιου.
        */
        
        
        new Main();
    }
}
