
/*
icsd15046 Γεωργιος Δουμουρας
icsd15055 Αθανασιος Ζαρκαδας
*/
/*Δεν καταφεραμε να βρουμε τις ακριβης εικονες που μας δειχνατε στην εργασια για τις εποχες.
Σε ενα πακετο που κατεβασαμε που βρηκαμε ολες τις εικονες που εχουμε δεν υπηρχαν μεσα.
Επειδη δεν ξεραμε αν θα δημηουργηθει προβλημα αν τα καναμε σκρινσοτ χρησιμοποιησαμε απο το πακετο που ειχε και τα υπολοιπα τα μαυρα tiles για τις εποχες. */
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
//Κανει extend την μαμα κλαση των tile που ειναι η Tile_AB
public class Season_Tile extends Tile_AB {
    
     Image img;
   //Constructor 
    public Season_Tile(int tile_number)
    {
        this.tile_number = tile_number;
        //Εδω παιρνει απο τον φακελο εποχες με τις εικονες που φτιαξαμε στο Default package μια εικονα και την εκχορει στην μεταβλητη img που φτιαξαμε παραπανω
        this.img = new ImageIcon(getClass().getResource("/SeasonsIcons/"+tile_number+".png")).getImage();
        Dimension size = new Dimension(img.getWidth(null), img.getHeight(null)); //Κανοντας παραπανω import την κλαση dimension θα την χρησιμοποιησουμε για να φτιαξουμε τα χαρακτηριστικα(διαστασεις του tile)
         //Δινουμε διαστασεις
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
        setSize(size);
        setLayout(null);
        setVisible(true);
    }
    //Συναρτηση για την δημιουργια γραφικων
    @Override
    public void paintComponent(Graphics g) {  
        g.drawImage(img, 10, 10, null);     //Παιρνει παραμετρους την εικονα img. Οι διαστασεις 10,10 που βαλαμε αντιστοιχουσαν καταλαλληλα ωστε να φαινεται σωστα το tile στην εξοδο
        
    }

    //Υλοποιουμε toString
    @Override
    public String toString()
    {
        return "Season number : " + this.tile_number;
    }
}
