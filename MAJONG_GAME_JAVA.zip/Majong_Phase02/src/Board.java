/*
icsd15046 Γεωργιος Δουμουρας
icsd15055 Αθανασιος Ζαρκαδας
 */

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.TexturePaint;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import jdk.nashorn.internal.runtime.regexp.joni.Config;

//Το Board μας θα ειναι Jpanel γιατι θα βρισκεται μεσα στο εξωτερικο μας JFrame
//της main κλασης μας.
public class Board extends JPanel {
//Η λογικη μας συνεχιζει οπως στην Α' φαση να  δουλευουμε με λιστες.

    private ArrayList<Tile_AB> tile_deck = new ArrayList<Tile_AB>();
    private ArrayList<Tile_AB> tile_deck2 = new ArrayList<Tile_AB>();//Arraylist Για τα tile που δημιουργουνε το board.
    private Tile_AB[][] board_array = new Tile_AB[12][8]; // Οριζω ενα πινακα 31(x_cords) και 4(y_cords)
    private ArrayList<Tile_AB> board_array_helper = new ArrayList<Tile_AB>(); // Αυτην η λιστα ειναι για να μας βοηθησει να υλοποιησουμε το τελος του παιχνιδιου.
    private Image backimg; // Δηλωνουμε μεταβλητη για να περασουμε το backround
    private JPanel pa1, pal2; //Δηλωνουμε Jpanel 
    private int flag = 1;
    private String string1, string2;
    private JPanel panel1, panel2;
//Constructor 

    public Board() {

        Create_Tiles(); //Αρχικα δημιουργουμε tiles και board πριν οποια αλλη ενεργεια.
        Create_Board();

        //Γραφικά Jpanel για την δημιουργέια του ταμπλό.
        setSize(800, 600); // Βαλαμε 800, 600 μετα απο δοκιμες γιατι ηταν το πιο καταλληλο
        this.backimg = new ImageIcon(getClass().getResource("/Images/back.jpg")).getImage(); //απο τον φακελο image θα παρουμε την εικονα που διαλεξαμε για backround και την τοποθετουμε
        Dimension size = new Dimension(backimg.getWidth(null), backimg.getHeight(null)); //Κανοντας παραπανω import την κλαση dimension θα την χρησιμοποιησουμε για να φτιαξουμε τα χαρακτηριστικα(διαστασεις του backround)
        //Υλοποιουμε διαστασεις για το backround
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
        setSize(size);
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //Με αυτη την διπλη επαναληψη θα γεμισουμε το board 8Χ12 tiles 
        for (int row = 0; row < 12; ++row) {
            for (int col = 0; col < 8; ++col) {
                //Για την παρακατω υλοποιηση πηραμε βοηθεια απο την Online ιστοσελιδα https://stackoverflow.com/
                c.fill = GridBagConstraints.HORIZONTAL;
                c.gridx = row;
                c.gridy = col;
                c.ipady = 20;
                c.ipadx = 20;
                c.insets = new Insets(0, 0, 0, 0);
                board_array_helper.add(board_array[row][col]);
                //Δημιουργουμε εναν Listener που αντιπροσοπευει τον κωδικα οταν ο χρηστης διαλεγει ενα tile 
                board_array[row][col].addMouseListener(new MouseAdapter() {
                    @Override  //συναρτηση η οποια παιρνει ως παραμετρο το κλικ του χρηστη
                    public void mousePressed(MouseEvent e) {
                        if (flag == 1) {        //Αν το χρηστης διαλεξει ενα κουτακι κραταμε την επιλογη του στο string 1
                            panel1 = (JPanel) e.getSource();
                            flag++;
                            string1 = panel1.toString();
                            System.out.println(string1);
                        } else if (flag == 2) {   // οταν ξαναδιαλεξει κραταμε την επιλογη του στο string 2 
                            panel2 = (JPanel) e.getSource();
                            flag++;
                            string2 = panel2.toString();
                            System.out.println(string2);
                            flag = 1;
                            if (string1.equals(string2)) {   //Υλοποιουμε την συναρτηση equals για να δουμε τις επιλογες του χρηστη αν ειναι ιδιες 
                                panel1.setVisible(false);//αν ειναι οι δυο επιλογες του χρηστη σβηνονται απο την εικονα.
                                panel2.setVisible(false);
                                for (int i = 0; i < board_array_helper.size(); i++) {  //με τον helper τον οποιο εχω κρατησει, μεσα σε αυτη την επαναληψη  ελεγχουμε αν το board ειναι κενο για να τερματισουμε το παιχνιδι.
                                    if (board_array_helper.get(i).toString().equals(string1)) {
                                        board_array_helper.remove(i);
                                    }
                                    if (board_array_helper.get(i).toString().equals(string2)) {
                                        board_array_helper.remove(i);
                                    }
                                    if (board_array_helper.size() > 0) { // επειδη η εργασια μας δεν δουλευει σωστα το βαζουμε μεγαλυτερο του μηδενος για να δουλεψει σιγουρα και να σας δειξουμε οτι υλοποιειται ο τερματισμος του παιχνιδιου
                                        int confirm = JOptionPane.showConfirmDialog(null,
                                                "Gongratulations you are a Winner !",
                                                "Message",
                                                JOptionPane.CLOSED_OPTION); //option για να εμφανιζεται το παραθυρο κλεισιματος
                                        System.exit(0); // το προγραμμα τελειωνει
                                    }

                                }

                            } else {
                                string1 = "";   // εδω αν δεν εχει διαλεξει τα ιδια tiles γεμιζουμε τα δυο String με κενο. Αυτο το κανουμε γιατι αντιμετοπιζαμε το προβλημα που οσο δουλευαμε το παιχνιδι τα string κραταγανε το περιεχομενο τους και δεν δουλευε σωστα το σβησιμο των σωστων tiles 
                                string2 = "";
                            }
                        }
                    }
                });

                add(board_array[row][col], c);

            }
        }

        setVisible(
                true);
    }

    //Κλαση για την προβολη της εικονας απο πίσω με γραφικα
    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(backimg, 0, 0, null);
    }
// Κωδικας A' φασης 
    // Συναρτηση που δημιουργει τα tiles την χρησιμοποιουμε στους constructor του board για να δημιουργησουμε τα 124 tiles.

    public void Create_Tiles() {
        for (int i = 1; i < 10; i++) {
            for (int j = 0; j < 4; j++) {
                tile_deck.add(new Character_Tile(i));
            }
        }
        for (int i = 1; i < 10; i++) {
            for (int j = 0; j < 4; j++) {
                tile_deck.add(new Circle_Tile(i));
            }
        }
        for (int i = 1; i < 10; i++) {
            for (int j = 0; j < 4; j++) {
                tile_deck.add(new Mpampou_Tile(i));
            }
        }
        for (int i = 1; i < 5; i++) {
            for (int j = 0; j < 2; j++) {
                tile_deck.add(new Season_Tile(i));
            }
        }
        for (int i = 1; i < 5; i++) {
            for (int j = 0; j < 2; j++) {
                tile_deck.add(new Flower_Tile(i));
            }
        }
    }
//Κωδικας Α' φασης 
    //ΔΗμιουργουμε τ ο board σε διαστασεις 12χ8 και μαζι με την create_tiles την τρεχουμε πρωτη στους constructors 

    public void Create_Board() {
        tile_deck2.clear();
        Random rand = new Random();
        int n;
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 8; j++) {
                n = rand.nextInt(tile_deck.size());
                tile_deck2.add(tile_deck.get(n));
                board_array[i][j] = tile_deck.get(n);
            }
        }

    }
}
