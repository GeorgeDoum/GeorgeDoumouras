/*
icsd15046 Γεωργιος Δουμουρας
icsd15055 Αθανασιος Ζαρκαδας
*/



//Δηλωνουμε κλαση για τον χρηστη
public class Player {
    private String name;
    //COnstructor
    public Player(String name)
    {
        this.name=name;
    }
    //set και get συναρτησεις
    public void set_Name(String name)
    {
        this.name=name;
    }
    
     public String get_Name()
    {
        return name;
    }
    //Δηλωνωουμε Tostring
    public String toString(String name)
    {
        return "Player name:" + name;
    }
    
}
