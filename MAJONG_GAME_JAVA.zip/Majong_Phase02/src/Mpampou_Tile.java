/*
icsd15046 Γεωργιος Δουμουρας
icsd15055 Αθανασιος Ζαρκαδας
*/


import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
//Κανει extend την μαμα κλαση των tile που ειναι η Tile_AB
public class Mpampou_Tile extends Tile_AB {
    
    Image img;
    //Constructor 
    public Mpampou_Tile(int tile_number)
    {
        this.tile_number = tile_number;
        //Εδω παιρνει απο τον φακελο μπαμπου με τις εικονες που φτιαξαμε στο Default package μια εικονα και την εκχορει στην μεταβλητη img που φτιαξαμε παραπανω
        this.img = new ImageIcon(getClass().getResource("/MpampouIcons/" + tile_number + ".png")).getImage(); 
        Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));//Κανοντας παραπανω import την κλαση dimension θα την χρησιμοποιησουμε για να φτιαξουμε τα χαρακτηριστικα(διαστασεις του tile)
         //Δινουμε διαστασεις
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
        setSize(size);
        setLayout(null);
        setVisible(true);
    }
     //Συναρτηση για την δημιουργια γραφικων
    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(img, 10, 10, null);   //Παιρνει παραμετρους την εικονα img. Οι διαστασεις 10,10 που βαλαμε αντιστοιχουσαν καταλαλληλα ωστε να φαινεται σωστα το tile στην εξοδο
    }

      //Υλοποιουμε toString
    @Override
    public String toString()
    {
        return "Mpampou number : " + this.tile_number;
    }
}
