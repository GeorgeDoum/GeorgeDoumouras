
/*
icsd15046 Γεωργιος Δουμουρας
icsd15055 Αθανασιος Ζαρκαδας
*/

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
//Κανει extend την μαμα κλαση των tile που ειναι η Tile_AB
public class Circle_Tile extends Tile_AB {

    Image img;
//Constructor 
    public Circle_Tile(int tile_number) {
        this.tile_number = tile_number;

        this.img = new ImageIcon(getClass().getResource("/CircleIcons/" + tile_number + ".png")).getImage();
        Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
        setPreferredSize(size);
        setMinimumSize(size);
        setMaximumSize(size);
        setSize(size);
        setLayout(null);
        System.out.println("Image Insert Message 1 Circle");
        setVisible(true);
    }
   //Συναρτηση για την δημιουργια γραφικων
    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(img, 10, 10, null);
    }
//Υλοποιουμε toString
    @Override
    public String toString() {
        return "Circle number : " + this.tile_number;
    }

}
