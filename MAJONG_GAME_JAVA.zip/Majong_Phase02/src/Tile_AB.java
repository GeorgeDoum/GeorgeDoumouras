/*
icsd15046 Γεωργιος Δουμουρας
icsd15055 Αθανασιος Ζαρκαδας
*/
//abstact (μαμα) κλαση για τις κλασεις που αντιστοιχουν στα tiles
import java.awt.Graphics;
import javax.swing.JPanel;
//Κανει extend το Jpanel γιατι θα είναι μεσα στο Jframe της main
abstract public class Tile_AB extends JPanel{

    protected int tile_number,x_cord,y_cord;
    private Tile_AB tile;
//Constructor
    public void Tile_AB(int tile_number) {
        this.tile_number = tile_number;
    }
    //Setters και Getters
    public void setX_Y(Tile_AB tile,int x_cord,int y_cord)
    {
        this.tile=tile;
        this.x_cord=x_cord;
        this.y_cord=y_cord;
    }
    
    public int get_X()
    {
        return this.x_cord;    
    }
    
    public int get_Y()
    {
        return this.y_cord;    
    }

    public int get_tile_number() {
        return this.tile_number;
    }
    
//Με αυτη την συναρτηση θα μπορεσω να τσεκαρω αν τα tiles ειναι ιδια
    public int Match_Tiles(Tile_AB Object) {
        //Οταν υλοποιειται θα τσεκαρει αν τα tiles ειναι ιδια και θα τα εξαφανιζει αλλιως θα τα αφηνει ως εχουν
        if (this.getClass() == Object.getClass()) {
            return 1;
        }else
        {
            return 0;
        }
    }
//Υλοποιουμε toString
    public String toString() {
        return "Tile number : " + this.tile_number;
    }
    //Συναρτηση που θα κανουν override οι κλάσεις που θα κληρωνομησουν απο αυτην. Την υλοποιουμε για να μπορουν καιι οι κλασεις με τα tiles να το κανουν
    @Override public void paintComponent(Graphics g){}

}
