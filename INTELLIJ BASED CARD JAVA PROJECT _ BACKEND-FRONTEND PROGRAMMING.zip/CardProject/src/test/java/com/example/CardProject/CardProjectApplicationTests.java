package com.example.CardProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
