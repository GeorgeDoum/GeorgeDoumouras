package com.example.CardProject.repositories;

import com.example.CardProject.apihelpers.BaseRepository;
import com.example.CardProject.entities.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface CardRepository extends BaseRepository<Card, Integer> {
    Card findOneById(Integer cardId);
}