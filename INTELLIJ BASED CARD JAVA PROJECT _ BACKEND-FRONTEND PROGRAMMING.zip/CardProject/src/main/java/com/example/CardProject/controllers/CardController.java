package com.example.CardProject.controllers;

import com.example.CardProject.entities.Card;
import com.example.CardProject.repositories.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class CardController {

    @Autowired
    CardRepository cardRepository;

    @PostMapping("/card/create")
    public Card createCard(@Valid @RequestBody Card card) {
        System.out.println("Card Created");
        return cardRepository.save(card);
    }

    @PutMapping("/card/update/{id}")
    public Card updateNote(@PathVariable(value = "id") int cardId, @Valid @RequestBody Card cardDetails) {
        System.out.println("Card Update");
        Card card = cardRepository.findOneById(cardId);
        card.setProduct(cardDetails.getProduct());
        Card updatedCard = cardRepository.save(card);
        return updatedCard;
    }

    @GetMapping("/card/{id}")
    public Card getById(@PathVariable(value = "id") int cardId){
        System.out.println("Card Found");
        return  cardRepository.findOneById(cardId);
    }

    @PutMapping("/card/reset/{id}")
    public Card resetCard(@PathVariable(value = "id") int cardId){
        System.out.println("Card Reseted");
        Card card = cardRepository.findOneById(cardId);
        card.setCard_name(null);
        card.setProduct(null);
        Card resetedCard= cardRepository.save(card);
        return resetedCard;
    }

    @DeleteMapping("/card/delete/{id}")
    public ResponseEntity<?> deleteCard(@PathVariable(value = "id") int cardId){
        System.out.println("Card Deleted");
        Card card = cardRepository.findOneById(cardId);
        cardRepository.delete(card);
        return ResponseEntity.ok().build();
    }

}