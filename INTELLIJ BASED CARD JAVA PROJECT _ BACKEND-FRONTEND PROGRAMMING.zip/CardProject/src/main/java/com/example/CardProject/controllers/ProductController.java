package com.example.CardProject.controllers;

import com.example.CardProject.entities.Product;
import com.example.CardProject.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import javax.validation.Valid;
import java.util.List;

@RestController
public class ProductController {

    @Autowired
    ProductRepository productRepository;

    @PostMapping("/product/create")
    public Product createProduct(@Valid @RequestBody Product product) {
        System.out.println(product.toString() + "created !");
        return productRepository.save(product);
    }

    @GetMapping("/product")
    public List<Product> getProduct() {
        System.out.println("All Products returned");
        return  productRepository.findAll();
    }
}