
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.security.NoSuchAlgorithmException;
import javax.crypto.NoSuchPaddingException;
//h klash auth einai h endiamesh ths anazhthshs bibliou. to frame pou anoigei exei mono 2 koumpia. edw o xrhsths tha dialeksei an to bilbio tha to psaksei bash tilou h isbn
public class TypeBookSearch {

    private JButton STitle, SISBN;
    private JFrame Frame = new JFrame("Select A Search Choice"); //neo parathuro

    public TypeBookSearch(final ObjectOutputStream out) throws NoSuchAlgorithmException, NoSuchPaddingException {
        Frame.setSize(400, 200); //grafika
        Frame.setVisible(true);
        Frame.getContentPane().setBackground(Color.white);
        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + "Select a Search Type" + "</span></html>", JLabel.CENTER);
        STitle = new JButton("Search By Title");
        STitle.setBounds(220, 100, 150, 30);
        SISBN = new JButton("Search By ISBN");
        SISBN.setBounds(40, 100, 150, 30);

        Frame.add(tittle);
        Frame.add(STitle);
        Frame.add(SISBN);
        Frame.setLayout(null);
        tittle.setBounds(100, 30, 200, 30);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);

        
        
                STitle.addActionListener(new ActionListener() { // otan dialeksei to login tha treksei h klash book titlesearch kai tha zhthsh ton titlo
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new BookTitleSearch(out);//kaleitai h klash
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );

        SISBN.addActionListener(new ActionListener() { //omoiws an dialeksei isbn
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new BookIsbnSearch(out);
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );
        
        
    }
}
