/*Georgios Doumouras
    3212015046
*/
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.NoSuchProviderException;
/*me thn main ftiaxnw thn roh kai dhmiourgw ena antikeimeno librarymenu etsi wste na ksekinisei to programma kai na mpei o xrhsths sto arxiko grafiko periballon */
public class Main {
    public static void main(String[] args) throws NoSuchProviderException{
        ObjectOutputStream out = null; //dhmiourgw tn roh
        try {
            out = new ObjectOutputStream(new FileOutputStream("LibraryObjects.txt"));//dhmiourgia arxeiou antikimenwn txt
        } catch (FileNotFoundException ex) {
            System.out.println("Error with specified file");
            ex.printStackTrace();
        } catch (IOException ex) {
            System.out.println("Error with I/O processes");
            ex.printStackTrace();
        }
        LibraryMenu menu = new LibraryMenu(out); //trexw ena antikeimeno tupou libraymenu gia na anoiksei to grafiko periballon
    }
    
}
