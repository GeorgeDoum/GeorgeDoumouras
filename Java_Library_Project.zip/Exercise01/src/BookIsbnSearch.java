
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.NoSuchPaddingException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
public class BookIsbnSearch {
//edw me auth thn klash an o xrhsths exei dialeksei na anazhthsh bash isbn tha klithei h sugkekrimenh sunarthsh
    private JLabel ISBN;
    private JTextField I1;
    private JButton Confirm, Exit;
    private JTextArea Result;
    private JFrame Frame = new JFrame("Searching a Book"); //neo parathuro

    public BookIsbnSearch(final ObjectOutputStream out) throws NoSuchAlgorithmException, NoSuchPaddingException {
        Frame.setSize(450, 300); //grafika
        Frame.setVisible(true);
        Frame.getContentPane().setBackground(Color.white);
        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + "Search A Book" + "</span></html>", JLabel.CENTER);

        ISBN = new JLabel("ISBN:");
        ISBN.setBounds(90, 70, 200, 20);
        I1 = new JTextField(200);
        I1.setBounds(200, 70, 200, 20);

        Confirm = new JButton("Confirm");
        Confirm.setBounds(220, 150, 170, 30);
        Exit = new JButton("Exit");
        Exit.setBounds(85, 150, 100, 30);
        Frame.add(tittle);
        Frame.add(ISBN);
        Frame.add(I1);
        Frame.add(Confirm);
        Frame.add(Exit);
        Frame.setLayout(null);
        tittle.setBounds(140, 30, 150, 30);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);
        Result = new JTextArea(100, 100);
        Result.setBounds(30, 120, 800, 80);

        Exit.addActionListener(new ActionListener() { //eksodos apo to parathuro
            @Override
            public void actionPerformed(ActionEvent e) {
                Frame.dispose();
            }
        }
        );
        Confirm.addActionListener(new ActionListener() {  //me to confirm koumpi tha trexw olo to txt gia na brv an uparxei o isbn pou zhthse o xrhsths
            @Override
            public void actionPerformed(ActionEvent e
            ) {
                try {
                    ObjectInputStream in;
                    LibraryObject Object;
                    in = new ObjectInputStream(new FileInputStream("LibraryObjects.txt"));
                    String bresult = "";

                    while (true) {
                        Object = (LibraryObject) in.readObject(); 

                        if (Object.getISBN().equals(ISBN.getText())) { //an uparxei to isbn krataw ta stoixeia tou bibliou
                            Result.setText(Object.toString());
                        }
                        if (ISBN.getText().equals("")) {
                            JOptionPane.showMessageDialog(null, "Συμπληρώστε το πεδίο.", "Error", JOptionPane.ERROR_MESSAGE); //elegxos gia to an o xrhsths egrapse kati sto text field
                        }
                    }
                } catch (FileNotFoundException ex) {
                    System.out.println("Error with specified file");
                    ex.printStackTrace();
                } catch (IOException ex) {

                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(BookIsbnSearch.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        );

    }
}
