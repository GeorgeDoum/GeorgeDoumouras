/*Georgios Doumouras
 3212015046
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.NoSuchPaddingException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
//klash menu. edw mesa ulopoiw tis epiloges tou xrhsth sto grafiko periballon.
public class LibraryMenu {

    private final JButton button1 = new JButton("Add a book in the library"); // dhmiourgw ta koumpia poy exei thn dunatothta o xrhsths na xrhsimopoieisei
    private final JButton button2 = new JButton("Add a magazine in the library");
    private final JButton button3 = new JButton("Search a book");
    private final JButton button4 = new JButton("Search a magazine");
    private final JButton button5 = new JButton("Exit");
    private final JFrame Frame = new JFrame("Library Menu"); //ftiaxnw to parathiro me titlo lib menu

    public LibraryMenu(final ObjectOutputStream out) {
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //ulopoiw ta grafika parakatw gia oles tis dunates epiloges tou  xrhsth mesa sto programma.
        Frame.setSize(300, 300);
        Frame.setVisible(true);

        JPanel contentPane = new JPanel(new GridBagLayout());
        contentPane.setOpaque(true);
        contentPane.setBackground(Color.white);
        Frame.getContentPane().setBackground(Color.white);
        String s = "";
        ImageIcon image = new ImageIcon("src/Images/back.png");
        JLabel imageLabel = new JLabel(image, JLabel.CENTER);
        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + s + "</span></html>", JLabel.CENTER);
        imageLabel.setVisible(true);

        button1.setFont(new Font("Arial", Font.BOLD, 15)); //ylopoiw ola ta koumpia pou tha fainontai ston xrhsth
        button1.setPreferredSize(new Dimension(100, 100));
        button1.setMinimumSize(new Dimension(250, 25));
        button2.setFont(new Font("Arial", Font.BOLD, 15));
        button2.setPreferredSize(new Dimension(100, 100));
        button2.setMinimumSize(new Dimension(250, 25));
        button3.setFont(new Font("Arial", Font.BOLD, 15));
        button3.setPreferredSize(new Dimension(100, 100));
        button3.setMinimumSize(new Dimension(250, 25));
        button4.setFont(new Font("Arial", Font.BOLD, 15));
        button4.setPreferredSize(new Dimension(100, 100));
        button4.setMinimumSize(new Dimension(250, 25));
        button5.setFont(new Font("Arial", Font.BOLD, 15));
        button5.setPreferredSize(new Dimension(100, 100));
        button5.setMinimumSize(new Dimension(250, 25));

        GridBagConstraints c = new GridBagConstraints();
        contentPane.add(imageLabel, c);
        contentPane.add(tittle);
        c.insets = new Insets(10, 10, 10, 10);
        c.gridx = 0;
        c.gridy = 1;
        contentPane.add(imageLabel, c);
        c.gridx = 0;
        c.gridy = 2;
        contentPane.add(button1, c);
        c.gridx = 0;
        c.gridy = 3;
        contentPane.add(button2, c);
        c.gridx = 0;
        c.gridy = 4;
        contentPane.add(button3, c);
        c.gridx = 0;
        c.gridy = 5;
        contentPane.add(button4, c);
        c.gridx = 0;
        c.gridy = 6;
        contentPane.add(button5, c);
        c.gridx = 0;
        c.gridy = 7;

        Frame.add(contentPane);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);
//parakatw einai oloi action listener. otan oxrhsths kanei klik se opoidhpote koumpi kaleitai h antistoixh klash
        button1.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { // kaleitai h klash gia eisagwgh bibliou
                try {
                    new Book(out);//Ανοιγω το Login
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );

        button2.addActionListener(new ActionListener() {// kaleitai h klash gia eisagwgh periodikou
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new Magazine(out);//Ανοιγω το Register
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );
        button3.addActionListener(new ActionListener() {// kaleitai h klash gia to eidos anazhthshs bibliou. titlos h isbn. tha anoiksei ena epipleon parathuro. dialegei o xrhsths me poio apo ta duo tha psaksei to biblio kai tha proxvrhsei h anazhthsh
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new  TypeBookSearch(out);
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );

        button4.addActionListener(new ActionListener() { // exw mia klash anazhthshs gia periodiko giati opws leei h askhsh prepei na eisagei ola ta aparaithta stoixeia pou zhta h askshh kai oxi ena apo 2 opws to biblio
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new SearchMagazine(out);
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(LibraryMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );

        button5.addActionListener(new ActionListener() { //to koumpi exit kleinei to frame
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        }
        );

    }

}
