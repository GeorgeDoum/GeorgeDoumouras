/*Georgios Doumouras
 3212015046
 */

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.NoSuchPaddingException;
// kalsh gia eisagwgh bibliou
public class Book {
// labels gia ola ta stoixeia pou prepei na exei enabiblio
    private JLabel Title, ISBN, Author, Year, Category, PagesNum, Lib_Position;
    private JTextField T1, I1, A1, Y1, C1, P1, LP1;
    private JButton Confirm, Exit; //koumpia gia tis epiloges eksodos h confirm
    private JFrame Frame = new JFrame("Adding a Book in the library"); //anoigw ena kainourgio parathiro

    public Book(final ObjectOutputStream out) throws NoSuchAlgorithmException, NoSuchPaddingException {
        Frame.setSize(500, 650); //grafika gia to parathiro
        Frame.setVisible(true);
        Frame.getContentPane().setBackground(Color.white);
        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + "Add A Book" + "</span></html>", JLabel.CENTER);

        Title = new JLabel("Title:"); //grafika gia ola ta labels kai text fields
        Title.setBounds(90, 70, 200, 20);
        T1 = new JTextField(150);
        T1.setBounds(200, 70, 200, 20);

        ISBN = new JLabel("ISBN :");
        ISBN.setBounds(90, 100, 200, 20);
        I1 = new JTextField(150);
        I1.setBounds(200, 100, 200, 20);

        Author = new JLabel("Author :");
        Author.setBounds(90, 130, 200, 20);
        A1 = new JTextField(150);
        A1.setBounds(200, 130, 200, 20);

        Year = new JLabel("Year :");
        Year.setBounds(90, 160, 200, 20);
        Y1 = new JTextField(150);
        Y1.setBounds(200, 160, 200, 20);

        Category = new JLabel("Category :");
        Category.setBounds(90, 190, 200, 20);
        C1 = new JTextField(150);
        C1.setBounds(200, 190, 200, 20);

        PagesNum = new JLabel("Arithmos selidwn :");
        PagesNum.setBounds(90, 220, 200, 20);
        P1 = new JTextField(150);
        P1.setBounds(200, 220, 200, 20);

        Lib_Position = new JLabel("Thesh rafiou :");
        Lib_Position.setBounds(90, 250, 200, 20);
        LP1 = new JTextField(150);
        LP1.setBounds(200, 250, 200, 20);

        Confirm = new JButton("Confirm");
        Confirm.setBounds(220, 290, 170, 30);
        Exit = new JButton("Exit");
        Exit.setBounds(85, 290, 100, 30);

        Frame.add(tittle); // emfanizontai ta frame sto parathiro
        Frame.add(Title);
        Frame.add(T1);
        Frame.add(ISBN);
        Frame.add(I1);
        Frame.add(Author);
        Frame.add(A1);
        Frame.add(Year);
        Frame.add(Y1);
        Frame.add(Category);
        Frame.add(C1);
        Frame.add(PagesNum);
        Frame.add(P1);
        Frame.add(Lib_Position);
        Frame.add(LP1);
        Frame.add(Confirm);
        Frame.add(Exit);
        Frame.setLayout(null);
        tittle.setBounds(140, 30, 200, 30);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);

        Exit.addActionListener(new ActionListener() { //me to koumpi exit kleinei to frame
            @Override
            public void actionPerformed(ActionEvent e) {
                Frame.dispose();
            }
        }
        );
 //epilogh tou koumpiou confirm
        Confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //elegxos egkurothtas gia to an o xrhsths egrapse ola ta stoixeia
                if (T1.getText().equals("") || I1.getText().equals("") || A1.getText().equals("") || Y1.getText().equals("") || C1.getText().equals("") || P1.getText().equals("") || LP1.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Παρακαλώ Συμπληρώστε όλα τα Πεδία.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        File newFolder = new File("LibraryObjects/" + I1.getText());//dhmiourgia fakelou gia to arxeio

                        boolean created = newFolder.mkdir();

                        if (created) {
                            System.out.println("Folder was created !");
                            JOptionPane.showMessageDialog(null, "Folder was created !", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            System.out.println("Unable to create folder");
                        }//an ola einai swsta tha emfanistei panel me munhma epituxias
                        out.writeObject(new LibraryObject(T1.getText(), I1.getText(), A1.getText(), Y1.getText(), C1.getText(), P1.getText(), LP1.getText()));
                        out.flush();
                        JOptionPane.showMessageDialog(null, "Το βιβλίο με κωδικό ISBN " + I1.getText() + " και τίτλο " + T1.getText() + "καταχωρήθηκε στην βιβλιοθήκη", "Success", JOptionPane.INFORMATION_MESSAGE);
                        T1.setText("");
                        I1.setText("");
                        A1.setText("");
                        Y1.setText("");
                        C1.setText("");
                        P1.setText("");
                        LP1.setText("");
                    } catch (UnsupportedEncodingException ex) {
                        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (Exception ex) {
                        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }

        }
        );
    }

}
