/*Georgios Doumouras
 3212015046
 */

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.NoSuchPaddingException;
//klash gia thn eisagwgh periodikou. einai akribws h idia logikh me thn klash book gia thn eisagwgh bibliou. h monh diafora einai pws edw exw alla dedomena pou tha prepei na eisagei o xrhsths. h logikh einai idia 
//deite sxolia ths klash book
public class Magazine {

    private JLabel Title, Tomos, Year, NumTeuxos, Category, PagesNum, Lib_Position;
    private JTextField T1, TO1, Y1, N1, C1, P1, LP1;
    private JButton Confirm, Exit;
    private JFrame Frame = new JFrame("Adding a Magazine in the library");

    public Magazine(final ObjectOutputStream out) throws NoSuchAlgorithmException, NoSuchPaddingException {

        Frame.setSize(500, 650);
        Frame.setVisible(true);
        Frame.getContentPane().setBackground(Color.white);
        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + "Add A Magazine" + "</span></html>", JLabel.CENTER);

        Title = new JLabel("Title:");
        Title.setBounds(90, 70, 200, 20);
        T1 = new JTextField(150);
        T1.setBounds(200, 70, 200, 20);

        Tomos = new JLabel("Tomos:");
        Tomos.setBounds(90, 100, 200, 20);
        TO1 = new JTextField(150);
        TO1.setBounds(200, 100, 200, 20);

        Year = new JLabel("Year :");
        Year.setBounds(90, 160, 200, 20);
        Y1 = new JTextField(150);
        Y1.setBounds(200, 160, 200, 20);
        NumTeuxos = new JLabel("Arithmos Teuxous :");
        NumTeuxos.setBounds(90, 130, 200, 20);
        N1 = new JTextField(150);
        N1.setBounds(200, 130, 200, 20);

        Category = new JLabel("Category :");
        Category.setBounds(90, 190, 200, 20);
        C1 = new JTextField(150);
        C1.setBounds(200, 190, 200, 20);

        PagesNum = new JLabel("Arithmos selidwn :");
        PagesNum.setBounds(90, 220, 200, 20);
        P1 = new JTextField(150);
        P1.setBounds(200, 220, 200, 20);

        Lib_Position = new JLabel("Thesh rafiou :");
        Lib_Position.setBounds(90, 250, 200, 20);
        LP1 = new JTextField(150);
        LP1.setBounds(200, 250, 200, 20);

        Confirm = new JButton("Confirm");
        Confirm.setBounds(220, 290, 170, 30);
        Exit = new JButton("Exit");
        Exit.setBounds(85, 290, 100, 30);

        Frame.add(tittle);
        Frame.add(Title);
        Frame.add(T1);
        Frame.add(Tomos);
        Frame.add(TO1);
        Frame.add(NumTeuxos);
        Frame.add(N1);
        Frame.add(Year);
        Frame.add(Y1);
        Frame.add(Category);
        Frame.add(C1);
        Frame.add(PagesNum);
        Frame.add(P1);
        Frame.add(Lib_Position);
        Frame.add(LP1);
        Frame.add(Confirm);
        Frame.add(Exit);
        Frame.setLayout(null);
        tittle.setBounds(140, 30, 200, 30);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);

        Exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Frame.dispose();
            }
        }
        );

        Confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Ελεγχω αν ολα τα παιδια ειναι γεματα
                if (T1.getText().equals("") || TO1.getText().equals("") || N1.getText().equals("") || Y1.getText().equals("") || C1.getText().equals("") || P1.getText().equals("") || LP1.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Παρακαλώ Συμπληρώστε όλα τα Πεδία.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        File newFolder = new File("LibraryObjects/" + T1.getText());//Δημιουργία φακέλου του χρήστη

                        boolean created = newFolder.mkdir();

                        if (created) {
                            System.out.println("Folder was created !");
                            JOptionPane.showMessageDialog(null, "Folder was created !", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            System.out.println("Unable to create folder");
                        }

                        //Κρυπτογραφω το hash με το private κευ που εχω,
                        //και ολοκληρωνω την εγγραφη περνοντας τον χρηστη μεσα στο Users.txt
                        out.writeObject(new LibraryObject(T1.getText(), TO1.getText(), N1.getText(), Y1.getText(), C1.getText(), P1.getText(), LP1.getText()));
                        out.flush();
                        JOptionPane.showMessageDialog(null, "Το περιοδικό με τίτλο " + T1.getText() + " καταχωρήθηκε στην βιβλιοθήκη", "Success", JOptionPane.INFORMATION_MESSAGE);
                        T1.setText("");
                        TO1.setText("");
                        N1.setText("");
                        Y1.setText("");
                        C1.setText("");
                        P1.setText("");
                        LP1.setText("");
                    } catch (UnsupportedEncodingException ex) {
                        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (Exception ex) {
                        Logger.getLogger(Book.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
        );
    }

}
