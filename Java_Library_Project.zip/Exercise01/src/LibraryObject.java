
import java.io.Serializable;

/*Georgios Doumouras
 3212015046
 */
//klash gia ta antikeimena library object gia na ulopoihsw serializable objects
public class LibraryObject implements Serializable{

    private String Title, ISBN, Author, Year, Category, PagesNum, Lib_Position;
    //constuctor
    public LibraryObject(String Title, String ISBN, String Author, String Year, String Category, String PagesNum, String Lib_Position) {
        this.Title = Title;
        this.ISBN = ISBN;
        this.Author = Author;
        this.Year = Year;
        this.Category = Category;
        this.PagesNum = PagesNum;
        this.Lib_Position = Lib_Position;
    }//getters
    public String getTitle() {
        return Title;
    }

    public String getISBN() {
        return ISBN;
    }

    public String getAuthor() {
        return Author;
    }

    public String getYear() {
        return Year;
    }

    public String getCategory() {
        return Category;
    }

    public String getPagesNum() {
        return PagesNum;
    }

    public String getLib_Position() {
        return Lib_Position;
    }
    @Override
    public String toString() {
        return "LibraryObject{" + "Title=" + Title + ", ISBN=" + ISBN + ", Author=" + Author + ", Year=" + Year + ", Category=" + Category + ", PagesNum=" + PagesNum + ", Lib_Position=" + Lib_Position + '}';
    }

}
