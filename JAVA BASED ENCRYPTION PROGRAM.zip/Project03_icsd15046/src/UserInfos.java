/*Georgios Doumouras
    321/2015046*/
import java.io.Serializable;
//import java.util.Base64;

/*Η ΣΥΓΚΕΚΡΙΜΕΝΗ ΚΛΑΣΗ ΕΙΝΑΙ Η ΚΕΝΤΡΙΚΗ ΚΛΑΣΗ ΑΠΟΘΗΚΕΥΣΗΣ ΜΟΥ
Η ΟΠΟΙΑ ΜΕ ΒΟΗΘΑΕΙ ΣΤΟ ΝΑ ΑΠΟΘΗΚΕΥΩ ΟΛΟΥΣ ΤΟΥΣ ΧΡΗΣΤΕΣ ΚΑΤΑ ΤΗΝ ΕΓΓΡΑΦΗ ΤΟΥΣ
ΣΕ ΕΝΑ ΣΥΓΚΕΚΡΙΜΕΝΟ ΑΡΧΕΙΟ ΤΟ ΟΠΟΙΟ ΕΧΩ ΑΝΟΙΞΕΙ ΜΕ ΡΟΗ ΓΙΑ ΑΥΤΟ ΚΑΙ SERIALIZABLE.
ΕΠΙΣΗΣ ΟΡΙΖΩ CONSTUCTOR ΚΑΙ GET MEΘΟΔΟΥΣ ΚΑΘΩΣ ΚΑΙ ΣΤΟΝ ΚΩΔΙΚΟ Η GET ΜΕΘΟΔΟΣ ΤΟΥ
ΤΟ ΔΗΜΙΟΥΡΓΕΙ ΠΡΩΤΑ ΣΕ STRING ΒΑΣΗ ΤΟΥ BASE64 (ΤΟ ΟΠΟΙΟ ΕΙΝΑΙ ΣΕ ΣΧΟΛΙΟ ΔΙΟΤΙ ΔΗΜΙΟΥΡΓΕΙ ΠΡΟΒΛΗΜΑ ΣΤΟ BUILD ΟΜΩς ΛΕΙΤΟΥΡΓΕΙ ΤΟ ΠΡΟΓΡΑΜΜΑ ΑΦΟΥ ΕΧΩ ΕΝΤΑΞΕΙ ΤΑ JAR ΑΡΧΕΙΑ)
ΤΟ HASH(ΒΥΤΕ ΑΡΡΑΥ) ΠΟΥ ΕΧΕΙ 
ΠΑΡΕΙ ΑΠΟ ΤΗΝ ΕΓΓΡΑΦΗ KAI TO EΠΙΣΤΕΦΕΙ ΣΑΝ STING.*/
public class UserInfos implements Serializable {
    
    private String Name,Surname,Username,Password;
    
    public UserInfos(String Name,String Surname,String Username ,String Password)  
    {
        this.Name=Name;
        this.Surname=Surname;
        this.Username=Username;
        this.Password=Password;   
    }
    
    public String getName()
    {
        return Name;
    }
    public String getUsername()
    {
        return Username;
    }
    public String getSurname()
    {
        return Surname;
    }
    public String getPassword()
    {
        
        return Password;
    }

     public String toString(){
         return Surname + ":" + Password;
     }
    
    
}
