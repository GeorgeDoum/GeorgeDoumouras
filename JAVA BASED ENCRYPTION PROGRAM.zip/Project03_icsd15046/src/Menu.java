/*Georgios Doumouras
    321/2015046*/
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectOutputStream;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.NoSuchPaddingException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Menu {

    private final JButton button1 = new JButton("Log In User");
    private final JButton button2 = new JButton("Register User");
    private final JButton button3 = new JButton("Exit");
    private final JFrame Frame = new JFrame("Main Menu");

    public Menu(final ObjectOutputStream out) {

        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Frame.setSize(300, 300);
        Frame.setVisible(true);

        JPanel contentPane = new JPanel(new GridBagLayout());
        contentPane.setOpaque(true);
        contentPane.setBackground(Color.white);
        Frame.getContentPane().setBackground(Color.white);
        String s = "";
        ImageIcon image = new ImageIcon("src/Images/back.png");
        JLabel imageLabel = new JLabel(image, JLabel.CENTER);
        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + s + "</span></html>", JLabel.CENTER);
        imageLabel.setVisible(true);

        button1.setFont(new Font("Arial", Font.BOLD, 15));
        button1.setPreferredSize(new Dimension(100, 100));
        button1.setMinimumSize(new Dimension(250, 25));
        button2.setFont(new Font("Arial", Font.BOLD, 15));
        button2.setPreferredSize(new Dimension(100, 100));
        button2.setMinimumSize(new Dimension(250, 25));
        button3.setFont(new Font("Arial", Font.BOLD, 15));
        button3.setPreferredSize(new Dimension(100, 100));
        button3.setMinimumSize(new Dimension(250, 25));

        GridBagConstraints c = new GridBagConstraints();
        contentPane.add(imageLabel, c);
        contentPane.add(tittle);
        c.insets = new Insets(10, 10, 10, 10);
        c.gridx = 0;
        c.gridy = 1;
        contentPane.add(imageLabel, c);
        c.gridx = 0;
        c.gridy = 2;
        contentPane.add(button1, c);
        c.gridx = 0;
        c.gridy = 3;
        contentPane.add(button2, c);
        c.gridx = 0;
        c.gridy = 4;
        contentPane.add(button3, c);

        Frame.add(contentPane);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new LogIn(out);//Ανοιγω το Login
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new Register(out);//Ανοιγω το Register
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchPaddingException ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );

        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        }
        );

    }

}
