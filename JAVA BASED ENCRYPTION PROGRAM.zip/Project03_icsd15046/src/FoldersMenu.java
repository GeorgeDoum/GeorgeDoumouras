/*Georgios Doumouras
    321/2015046*/
import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.filechooser.FileSystemView;

public class FoldersMenu {

    private JButton New, Cryp, Open, List;
    private JFrame Frame = new JFrame(" Menu");
//constructor
    public FoldersMenu(final String User) {
//παρακατω υλοποιω τα γραφηκα για το μενου μετα το login 
        Frame.setSize(350, 300);
        Frame.setVisible(true);
        Frame.getContentPane().setBackground(Color.white);

        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + "Menu" + "</span></html>", JLabel.CENTER);

        New = new JButton("Προσθήκη Αρχείου");
        New.setBounds(62, 70, 220, 30);
        Cryp = new JButton("Κρυπτογράφηση/αποκρυπτογράφηση");
        Cryp.setBounds(62, 110, 220, 30);
        Open = new JButton("Άνοιγμα");
        Open.setBounds(62, 150, 220, 30);
        List = new JButton("Λίστα  αρχείων");
        List.setBounds(62, 190, 220, 30);

        Frame.add(tittle);
        Frame.add(New);
        Frame.add(Cryp);
        Frame.add(Open);
        Frame.add(List);
        Frame.setLayout(null);
        tittle.setBounds(75, 20, 200, 20);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);

        Open.addActionListener(new ActionListener() { //action listener για να χειριστω το κλικ του χρηστη.
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser jfc = new JFileChooser("src/"+User);
                int returnValue = jfc.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = jfc.getSelectedFile();
                    System.out.println(selectedFile.getAbsolutePath());//Περνω το Path του αρχειου.
                    try {
                        Desktop.getDesktop().open(new File(selectedFile.getAbsolutePath()));//Tο ανοιγω με την εφαρμογη του υπολογιστη και οχι μεσω netbeans
                    } catch (IOException ex) {
                        Logger.getLogger(FoldersMenu.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
        }
        );
//νεο listener για την επομενη επιλογη του menu για να αντιγραψω το αρχειο που θα διαλεξει ο χρηστης
        New.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                int returnValue = jfc.showOpenDialog(null);
                //https://stackoverflow.com/questions/1146153/copying-files-from-one-directory-to-another-in-java
                if (returnValue == JFileChooser.APPROVE_OPTION) {//Copy του αρχείου που θέλω στον φάκελο.
                    File selectedFile = jfc.getSelectedFile();
                    System.out.println(selectedFile.getAbsolutePath());
                    copy(selectedFile.getAbsolutePath(), "src/" + User + "/" + selectedFile.getName());
                }
            }
        }
        );
// την κρυπτογραφηση δυστυχως δεν καταφερα να την υλοποιηση στο project μου.
        Cryp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Η κρυπτογραφηση δεν εγινε :) !");
            }
        }
        );
// listener για να διαχειριστω το κλικ παλι
        List.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Εμφάνισει τον αρχείων.
                File folder = new File("src/" + User);

                String[] files = folder.list();

                for (String file : files) {
                    System.out.println(file);
                }
            }
        }
        );

    }

    public void copy(String from, String to) {
        FileReader fr = null;
        FileWriter fw = null;
        try {
            fr = new FileReader(from);
            fw = new FileWriter(to);
            int c = fr.read();
            while (c != -1) {
                fw.write(c);
                c = fr.read();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(fr);
            close(fw);
        }
    }

    public static void close(Closeable stream) {
        try {
            if (stream != null) {
                stream.close();
            }
        } catch (IOException e) {
            //...
        }
    }
}
