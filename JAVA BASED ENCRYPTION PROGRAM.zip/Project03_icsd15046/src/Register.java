/*Georgios Doumouras
    321/2015046*/
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.security.SecureRandom;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import static org.apache.commons.codec.digest.MessageDigestAlgorithms.SHA3_256;
import static org.apache.commons.codec.digest.MessageDigestAlgorithms.SHA_256;

public class Register {

    private JLabel Name, Surname, Username, Password, Email;
    private JTextField N1, S1, U1, P1, E1;
    private JButton Bregister, Bback;
    private String Pass;
    private JFrame Frame = new JFrame("Register");
    AssymetricKeys ac = new AssymetricKeys();
//constructor
    public Register(final ObjectOutputStream out) throws NoSuchAlgorithmException, NoSuchPaddingException {
     //υλοποιω γραφικα για το menu του register
        Frame.setSize(500, 350);
        Frame.setVisible(true);
        Frame.getContentPane().setBackground(Color.white);
        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + "Register" + "</span></html>", JLabel.CENTER);

        Name = new JLabel("Name:");
        Name.setBounds(90, 70, 200, 20);
        N1 = new JTextField(150);
        N1.setBounds(200, 70, 200, 20);
        Surname = new JLabel("Surname :");
        Surname.setBounds(90, 100, 200, 20);
        S1 = new JTextField(150);
        S1.setBounds(200, 100, 200, 20);
        Username = new JLabel("Username :");
        Username.setBounds(90, 130, 200, 20);
        U1 = new JTextField(150);
        U1.setBounds(200, 130, 200, 20);
        Password = new JLabel("Password :");
        Password.setBounds(90, 160, 200, 20);
        P1 = new JTextField(150);
        P1.setBounds(200, 160, 200, 20);

        Bregister = new JButton("Register");
        Bregister.setBounds(220, 250, 170, 30);
        Bback = new JButton("Back");
        Bback.setBounds(85, 250, 100, 30);

        Frame.add(tittle);
        Frame.add(Name);
        Frame.add(N1);
        Frame.add(Surname);
        Frame.add(S1);
        Frame.add(Username);
        Frame.add(U1);
        Frame.add(Password);
        Frame.add(P1);
        Frame.add(Bregister);
        Frame.add(Bback);
        Frame.setLayout(null);
        tittle.setBounds(160, 20, 200, 20);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);

        Bback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Frame.dispose();
            }
        }
        );

        Bregister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Ελεγχω αν ολα τα παιδια ειναι γεματα
                if (N1.getText().equals("") || S1.getText().equals("") || U1.getText().equals("") || P1.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Παρακαλώ Συμπληρώστε όλα τα Πεδία.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (AlreadyUser() == true) {
                    //ελενγχω αν ο χρηστης υπαρχει ηδη.
                    JOptionPane.showMessageDialog(null, "Ο χρήστης υπάρχει !", "Error", JOptionPane.ERROR_MESSAGE);
                    U1.setText("");
                } else {
                    try {
                        File newFolder = new File("src/"+N1.getText());//Δημιουργία φακέλου του χρήστη
                        
                        boolean created = newFolder.mkdir();

                        if (created) {
                            System.out.println("Folder was created !");
                            JOptionPane.showMessageDialog(null, "Folder was created !", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            System.out.println("Unable to create folder");
                        }

                        Pass = P1.getText();

                        //Κρυπτογραφω το password με τον SHA-256.
                        MessageDigest md = MessageDigest.getInstance("SHA-256");
                        Pass = P1.getText();
                        md.update(Pass.getBytes("UTF-8"));
                        byte[] digest = md.digest();
                        String PassHash = new String(digest, "UTF-8");

                        //Κρυπτογραφω το hash με το private κευ που εχω,
                        //και ολοκληρωνω την εγγραφη περνοντας τον χρηστη μεσα στο Users.txt
                        PrivateKey privateKey = ac.getPrivate("KeyPair/privateKey");
                        PublicKey publicKey = ac.getPublic("KeyPair/publicKey");

                        String msg = "Password Encrypt start!";
                        String encrypted_msg = ac.encryptText(PassHash, privateKey);
                        System.out.println("Original Message: " + msg
                                + "\nEncrypted Message: " + encrypted_msg);

                        if (new File("KeyPair/text.txt").exists()) {
                            ac.encryptFile(ac.getFileInBytes(new File("KeyPair/text.txt")),
                                    new File("KeyPair/text_encrypted.txt"), privateKey);
                            ac.decryptFile(ac.getFileInBytes(new File("KeyPair/text_encrypted.txt")),
                                    new File("KeyPair/text_decrypted.txt"), publicKey);
                        } else {
                            System.out.println("Create a file text.txt under folder KeyPair");
                        }
                        out.writeObject(new UserInfos(N1.getText(), S1.getText(), U1.getText(), encrypted_msg));
                        out.flush();
                        JOptionPane.showMessageDialog(null, N1.getText() + ", η εγγραφή σας ήταν επιτυχής.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        N1.setText("");
                        U1.setText("");
                        S1.setText("");
                        P1.setText("");

                    } catch (NoSuchAlgorithmException ex) {
                        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (UnsupportedEncodingException ex) {
                        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (Exception ex) {
                        Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
        );
    }

    /*ΣΥΝΑΡΤΗΣΗ ΕΛΕΓΧΟΥ ΓΙΑ ΤΟ ΑΝ ΥΠΑΡΧΕΙ ΕΙΔΗ Ο ΧΡΗΣΤΗΣ.*/
    public boolean AlreadyUser() {
        ObjectInputStream in;
        UserInfos User;
        boolean AS = false;
        try {
            in = new ObjectInputStream(new FileInputStream("Users.txt"));
            while (true) {
                User = (UserInfos) in.readObject();
                if (U1.getText().equals(User.getUsername())) {//ΣΥΚΡΙΣΗ USERNAME
                    AS = true;//AΡΑ USER EXIST ΚΑΙ ΔΕΝ ΔΗΜΙΟΥΡΓΕΙ ΞΑΝΑ USER.
                }
            }
        } catch (FileNotFoundException ex) {
            //Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            System.out.println("EOF");
        } catch (ClassNotFoundException ex) {
            // Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
        }
        return AS;
    }

}
