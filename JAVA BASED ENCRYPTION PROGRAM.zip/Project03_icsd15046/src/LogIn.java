/*Georgios Doumouras
    321/2015046*/
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.NoSuchPaddingException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class LogIn {

    private JLabel Username, Password;
    private JTextField U1, P1;
    private JButton BLogIn, Bback;
    private JFrame Frame = new JFrame("LogIn");
    private String Pass;
    AssymetricKeys ac = new AssymetricKeys();
//constructor 
    public LogIn(final ObjectOutputStream out) throws NoSuchAlgorithmException, NoSuchPaddingException {
//παρακατω υλοποιω τα γραφικα του menu.
        Frame.setSize(500, 250);
        Frame.setVisible(true);
        Frame.getContentPane().setBackground(Color.white);

        JLabel tittle = new JLabel("<html><span style='font-size:15px'>" + "Log In" + "</span></html>", JLabel.CENTER);

        Username = new JLabel("Username :");
        Username.setBounds(90, 70, 200, 20);
        U1 = new JTextField(150);
        U1.setBounds(200, 70, 200, 20);
        Password = new JLabel("Password :");
        Password.setBounds(90, 100, 200, 20);
        P1 = new JTextField(150);
        P1.setBounds(200, 100, 200, 20);

        BLogIn = new JButton("Log In");
        BLogIn.setBounds(220, 150, 170, 30);
        Bback = new JButton("Back");
        Bback.setBounds(85, 150, 100, 30);

        Frame.add(tittle);
        Frame.add(Username);
        Frame.add(U1);
        Frame.add(Password);
        Frame.add(P1);
        Frame.add(BLogIn);
        Frame.add(Bback);
        Frame.setLayout(null);
        tittle.setBounds(160, 20, 200, 20);
        Frame.setLocationRelativeTo(null);
        Frame.setResizable(false);

        Bback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Frame.dispose();
            }
        }
        );


        BLogIn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ObjectInputStream in;
                UserInfos User;
                try {
                    in = new ObjectInputStream(new FileInputStream("Users.txt"));
                    while (true) {
                        User = (UserInfos) in.readObject();
                        if (U1.getText().equals(User.getUsername())) {//Βρισκω το Username μεσα στο αρχειο Users.

                            //Κανω hash το password με τον SHA-256
                            MessageDigest md = MessageDigest.getInstance("SHA-256");
                            Pass = P1.getText();
                            md.update(Pass.getBytes("UTF-8"));
                            byte[] digest = md.digest();
                            String PassHash = new String(digest, "UTF-8");

                            PrivateKey privateKey = ac.getPrivate("KeyPair/privateKey");
                            PublicKey publicKey = ac.getPublic("KeyPair/publicKey");

                            //Κανω decrypt το password που εχω τραβιξει απο το αρχειο και συγκρινο τα δυο hash.
                            String msg = "Password Encrypt start!";
                            String decrypted_msg = ac.decryptText(User.getPassword(), publicKey);
                            System.out.println("Original Message: " + msg
                                    + "\nDecrypted Message: " + decrypted_msg);

                            if (new File("KeyPair/text.txt").exists()) {
                                ac.encryptFile(ac.getFileInBytes(new File("KeyPair/text.txt")),
                                        new File("KeyPair/text_encrypted.txt"), privateKey);
                                ac.decryptFile(ac.getFileInBytes(new File("KeyPair/text_encrypted.txt")),
                                        new File("KeyPair/text_decrypted.txt"), publicKey);
                            } else {
                                System.out.println("Create a file text.txt under folder KeyPair");
                            }

                            if (PassHash.equals(decrypted_msg)) {
                                System.out.println("You are the correct user");//Επιτυχία αυθεντικοποίησης!
                                new FoldersMenu(U1.getText());
                                Frame.dispose();
                            } else {
                                JOptionPane.showMessageDialog(null, "Ο χρήστης δεν υπάρχει ή έχετε κανει κάποιο λάθος!", "Error", JOptionPane.ERROR_MESSAGE);
                                P1.setText("");
                                U1.setText("");
                            }
                        }
                    }
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    System.out.println("EOF");
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
                } catch (NoSuchAlgorithmException ex) {
                    Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
                } catch (Exception ex) {
                    Logger.getLogger(LogIn.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );
    }

}
