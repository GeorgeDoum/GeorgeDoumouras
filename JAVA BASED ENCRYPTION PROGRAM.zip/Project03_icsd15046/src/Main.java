/*Georgios Doumouras
    321/2015046*/
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

public class Main {

    public static void main(String[] args) throws NoSuchProviderException {
        //Δημιουργία public key και private key. Βάση παραδείγματος (https://www.mkyong.com/java/java-asymmetric-cryptography-example/).     
        GenerateKeys gk;
        try {
            gk = new GenerateKeys(1024);
            gk.createKeys();
            gk.writeToFile("KeyPair/publicKey", gk.getPublicKey().getEncoded());//Δημιουργια Public Key
            gk.writeToFile("KeyPair/privateKey", gk.getPrivateKey().getEncoded());//Δημιουργια Private Key
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            System.err.println(e.getMessage());
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }

        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new FileOutputStream("Users.txt"));//Δημιουργια αρχειου αποθηκευσης χρηστων.
        } catch (FileNotFoundException ex) {
            System.out.println("Error with specified file");
            ex.printStackTrace();
        } catch (IOException ex) {
            System.out.println("Error with I/O processes");
            ex.printStackTrace();
        }

        Menu m = new Menu(out);//Καλεσμα κεντρικου μενου,και περασμα ττης ροης του αρχειου Users.
    }
}
