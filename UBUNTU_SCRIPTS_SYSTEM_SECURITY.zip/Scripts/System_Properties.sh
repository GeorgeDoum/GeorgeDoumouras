#!/bin/bash
#Georgios Doumouras
#3212015046

echo "Parakatw emfanizontai basikes plhrofories susthmatos"
echo " "
echo "To onoma tou eksuphrethth einai : " 
uname -a
echo " "
echo "H ekdosh einai: "
lsb_release -a
echo " "
echo "O xronos leitourgias tou susthmatos einai : "
$ uptime
echo " "
echo "Energoi xrhstes: "
who -a

echo "Oles oi ip twn xrhstwn einai : "
ip addr show


