#!/bin/bash
#Georgios Doumouras
#3212015946

echo "Oi xrhstes pou exoun dikaiomata diaxeiristh: "
grep -Po '^sudo.+:\K.*$' /etc/group
