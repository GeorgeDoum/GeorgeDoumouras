#!/bin/bash

#Georgios Doumouras
#321/2015046
#pairnw apo to xrhsth ta stoixeia tou
echo "Ksekinaei h dhmiourgia xrhsth"

echo "Parakalw dwse mou to username:"
read username
echo "Dwse mou ton kwdiko pou theleis:"
read password
echo "Dwse mou to mia perigrafh pou theleis:"
read description
echo "Dwse mou to group pou anhkeis:"
read group
#Tha xrhsimopoihsw while gia ton elegxo tou kwdikou
#h choice einai h metablhth pou tha mou termathsh h tha mou krathsei to loup
choice="y"
#epeidh den mporousa kanw elegxw gia to an uparxei apo 1-9 arithmos
#brhka ton parakatw tropo sto stackoverflow erwthsh 806906 bazontas mia
#syntikh se mia metablhth kai elegxontas to password me thn metablhth
re='^[0-9]+$'
#ulopoiw tis desmeuseis tou swstou pass
while  [[ "$password" != [[:upper:]] || "$password" != [[:lower:]] || "$password" != *['!'@#\$%^\&*()_+]*  || ${#password}<6 || "$password"!=re && "$choice" == "y" ]]
do
#afou kserw oti uparxei problhma me ton kwdiko epeidh mphke sto loup
#stis parakatw if elegxw ena ena tis proipotheseis kai an kapoia den threitai
# emfanizw mhnuma
	if  [[ "$password" != [[:upper:]] ]]
	then
		echo "Den Brethike kefalaio gramma"
	fi

	if  [[ "$password" != [[:lower:]] ]]
	then
        	echo "Den Brethike pezo gramma"
	fi

	if  [[ "$password" != *['!'@#\$%^\&*()_+]* ]]
	then
	        echo "Den Brethike sumbolo "
	fi

	if  [[ "$password" != re ]]
	then
	        echo "Den Brethike arithmos"
	fi
	
	if  [[ ${#password} < 6 ]]
	then
	        echo "O kwdikos exei ligoterous apo 6 xarakthres"
	fi
#Edw tha mou pei o xrhsths an thelei na dwsei allon kwdiko afou autos pou 
#mou edwse einai lathos h oxi
	echo "Thes na ksana prospathiseis h na termatisei to programma?"
	echo "Pata  'y' gia nai kai 'n' gia oxi "
	read choice 
#an allaksw to choice to loup stamataei alliws sunexizei
	if [[ "$choice" == "y" ]]
	then
		echo "Dwse neo kwdiko"
		read password
	fi
	if [[ "$choice" == "n" ]]
	then
		echo "termatismos"
		break
	fi
done
echo "H Dhmiourgia xrhsth oloklhrwthike me epituxia "


