#!/bin/bash
#georgios Doumouras
#3212015046
#epeleksa na emfanizw tis leptomeries sthn othonh
#tha xrhsimopoiw ena flag kai an auto pou diabazw einai == me to flag
#oi if tha einai true kai tha ulopoiounte alliws sunexizw
echo "Exete dunatothta na deite tis plhrofories systhmatos"
flag='y'
#oles oi plhrofories mazemenes se periptwsh pou den thelei mia sugkekrimenh
#gia auto einai sthn arxh
echo " "
echo "Thelete na deite oles tis plhrofories mazemenes? y an n an oxi "
read choice
if [[ "$choice" == "$flag" ]]
then
        echo " "
        echo "H katastash ths mnhmhs einai : "
        cat /proc/meminfo
        echo " "
        echo "H katastash tou diskou einai : "
        hdparm -I /dev/sda
        echo " "
        echo "H katastash tou epeksergasth einai : "
        cat /proc/cpuinfo
fi

#erwthsh gia mnhmh
echo "Thelete na deite thn katastash ths mnhmhs? y an nai n an oxi " 
read choice
if [[ "$choice" == "$flag" ]]
then
	cat /proc/meminfo
fi

#erwthsh gia disko
echo " "
echo "Thelete na deite thn katastash tou diskou? y an nai n an oxi "
read choice
if [[ "$choice" == "$flag" ]]
then
        hdparm -I /dev/sda
fi

#erwthsh gia cpu
echo " "
echo "Thelete na deite thn katastash tou epeksergasth? y an nai n an oxi "
read choice
if [[ "$choice" == "$flag" ]]
then
        cat /proc/cpuinfo
fi

