#!/bin/bash
#Georgios Doumouras
#3212015046

echo "Ta arxeia me dikaiomata SUID einai "
sudo find / -perm /4000
total=$(sudo find / -perm/4000 | wc -l)
echo "$total" 
