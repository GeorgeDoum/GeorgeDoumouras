#!/bin/bash
#georgios doumouras
#3212015046

echo " Parakatw emfanizontai ola ta listening ports"
#tha xrhsimopoihsw thn lsof -i 
#an hthela ena sugkekrimeno port tha eprepe na to orisw etsi -> :100
#se auth thn fash ta thelw ola
lsof -i

echo " " 
echo "END"
