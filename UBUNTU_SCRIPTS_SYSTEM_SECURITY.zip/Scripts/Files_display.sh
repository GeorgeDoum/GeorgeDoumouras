#!/bin/bash
#Georgios DOumouras
#3212015046
echo " "
echo "Parakatw emfanizontai arxeia pou alaxthikan/dhmiourghthikan sto susthma"
echo " "
#thn parakatw entolh thn brhka sthn istoselida askubuntu.com/questions/411462
#perigrammatika thn find thn xrhsimopoioume otan psaxnoume arxeia 
#h xargs mas bohthaei na xeiristoume kalutera input apo thn grep
#me thn sort ta arxeia tha einai taksinomimena
#me thn cut petixainw na oriothethsw ta arxeia sto output

find ${1} -type f | xargs stat --format '%Y :%y %n' 2>/dev/null |sort -nr | cut -d: -f2-

echo "TELOS EMFANISHS"
