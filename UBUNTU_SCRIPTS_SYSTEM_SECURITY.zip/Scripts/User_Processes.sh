#!/bin/bash
#georgios DOumouras
#3212015046

echo " Dwse mou ena username pou theleis na deis tis diergasies tou"
read usernam
echo " "
#h top - U mas dinei oles tis diergasies analutika
# $usernam to grafoume gia na mas pei gia auton mono
top -U $usernam

