#!/bin/bash
#Georgios doumouras
#3212015046

#diabazw to arxeio me tous xrhstes grammh grammh
cut -d: -f1 /etc/passwd
 #blepw an uparxei apotuxia login
#an xreiastei tha afksithei to try
	     try=try+1
		if [[try >0]]
		then
#emfanizw ta stoixeia pou prepei na kserei o xrhsths gia ta fail login
			echo "O xrhsths $line exei $try apotuxhmenes prospatheies eisodou"
			echo "O xrhsths $line exei ip : "
			ip addr show
			echo "H wra kai hm/nia tou susthmatos einai"
			echo date "+%H:%M:%S %d%m%y"
			break
		fi
#Orizw oti parapanw apo 3 apotyxies einai epithesh sto susthma
#opote ton diagrafw
		if [[try > 3 ]]
		then
			sudo passwd $line -l
			echo "Treis apotuximenes prospatheies"
			echo "O xrhsths xreiasthke na diagrafei"
			break
		fi
