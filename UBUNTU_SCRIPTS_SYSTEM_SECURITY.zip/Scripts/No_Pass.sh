#!/bin/bash
#Georgios Doumouras
#3212015046
#psanw osous den exoun kwdiko me thn getend shadow
sudo getend shadow | grep '^[^:]*:.\?:' | cut -d: -f1
echo "OI parapanw den exoun kwdiko
echo "to susthma tha prepei na tous diagrapsei"

#loup diavazw grammh grammh tous xrhstes kai opoios den exei password tn diagrafw

sudo getend shadow | grep '^[^:]*:.\?:' | cut -d: -f1 | while read line
do
	passwd $line -l
done

echo "diagrafh epituxhs"
