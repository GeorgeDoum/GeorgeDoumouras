/*  Giorgos Doumouras icsd15046
    Ergasia 2, Askhsh 1
*/
#include <stdio.h>
#define N 11                          //  Δεσμευω μεγεθος πινακα 11 αφου το μεγαλυτερο σωστο username που μπορουν να μου πουν ειναι του Σαχμ με 11 γραμματα και αριθμους
int main()
{

    char username[N];       //πινακας για το username
    int i;                      //μετρητης
    int option;            //αυτη θα την χρησιμοποιησω στο σημειο που θελω να δω αν συνεχιζει η κλεινει το προγραμμα ο χρηστης
    do
    {

        printf("Please give the username of the student or type 0 to end the program: \n");         //  Εδω μου δινει πρωτη φορα username
        scanf("%s", username);
        printf("\n");
        if(username[0]=='0')    //Με αυτη την If αν μου δωσει 0 σταματαει το προγραμμα
        {
            return 0;
        }
        if(username[0]!='a' && username[0]!='i' && username[0]!= 'm')           //Ελεγχος εγκηροτητας για το τι μου δινει χρησιμοποιω το πρωτο γραμμα για να καταλαβω αν το username αντιστοιχει σε ενα απο τα 3 τμηματα
        {
            printf("Wrong input please type actuar, icsd of math for the usernames");      // μηνυμα που του λεω τι να μου γραψει
            printf("\n");
            printf("Please give the username of the student: ");                       //    ξαναζηταω username
            scanf("%s", username);
            printf("\n");
        }
        if(username[5]=='r')                          //  Εδω κοιτοντας στο 6ο κουτακι του πινακα βλεπω αν μου εχει βαλει την λεξη actuar που αντιστοιχει στο ΣΑΧΜ
        {
            printf("The univercity department is SAXM");
            printf("\n");
            printf("The year of introduction is: 20");        //  Σε αυτη την for ποιανω την 7η και την 8η θεση του πινακα που βρισκονται τα νουμε που αντιστοιχουν στο ετος
            for (i=6; i<8 && username[i]!='\0'; ++i)
            {
                printf("%c", username[i]);         //  τα εμφανιζω βαζοντας τα μαζι με το Printf της γραμμης 34
            }
            printf("\n");
            printf("And The increasing number is: ");      // ιδια λογικη με το ετος και σε αυτη την for
            for(i=8; i<N && username[i]!='\0'; ++i)
            {
                printf("%c", username[i]);
            }


        }
        else if(username[6]!='r' && username[3]=='d')                //εδω ψαχνω το icsd εχοντας σαν παραμετρο το αν το 4ο κουτακι ειναι d το !='r' το βαζω διοτι δεν μου δουλευε αλλιως
        {

            printf("The Univercity department is MPES");
            printf("\n");
            printf("The year of introduction is: 20");         // ιδια λογικη με την πανω for αλλα αυτη την φορα για τις θεσεις 5 και 6 του πινακα
            for (i=4; i<6 && username[i]!='\0'; ++i)
            {
                printf("%c", username[i]);
            }
            printf("\n");
            printf("And The increasing number is: ");      // κοιταω απο το 6ο κουτακι μεχρι το τελος του String βαζοντας !='\0'
            for(i=6; i<N && username[i]!='\0'; ++i)
            {
                printf("%c", username[i]);
            }

        }
        else
        {
            printf("The Univercity department is MATHEMATICS");        //     Εδω φτανουμε στο τελευταιο σωστο  username που μπορει να μου δωσει για αυτο βαζω απλο else
            printf("\n");
            printf("The year of introduction is: 20");            //   και κανω τα ιδια ακριβως με το icsd
            for (i=4; i<6 && username[i]!='\0'; ++i)
            {
                printf("%c", username[i]);
            }
            printf("\n");
            printf("And The increasing number is: ");          // και εδω κοιταω μεχρι το τελος του string
            for(i=6; i<N && username[i]!='\0'; ++i)
            {
                printf("%c", username[i]);
            }
        }
        printf("\n\n");
        printf("If you want another check please type 1 or type 0 to close the programme");   //  φτανοντας εεδω ρωταω αν θελει να ξαναψαξει κατι
        scanf(" %d", &option);
        if (option==0)                 // αν μου δωσει 0  σταματαει αλλιως συνεχιζει παλι απο την αρχη το προγραμμα
        {
            return 0;
        }

    }
    while(option==1);

    return 0;
}
