/*  Giorgos Doumouras icsd15046
    Ergasia 2, Askhsh 3
*/
#include <stdio.h>
#include <time.h>
#
int main()
{
    srand(time(NULL));                       //   συναρτηση για τους τυχαιους αριθμους
    int kerdos;                           //  δηλωνω μεταβλητες του προγραμματος
    int lucky_num[20];
    int i, j;
    int poso;
    int count;
    int num;
    int choice;
    int number[12];
    int rendition[12][13]= {{0, 2.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},{0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0,0,2.5,25,0,0,0,0,0,0,0,0,0},{0,0,1,4,100,0,0,0,0,0,0,0,0},
        {0,0,0,2,20,450,0,0,0,0,0,0,0},{0,0,0,1,7,50,1600,0,0,0,0,0,0},
        {0,0,0,1,3,20,100,5000,0,0,0,0,0},{0,0,0,0,2,10,50,1000,15000},
        {0,0,0,0,1,5,25,200,4000,40000},
        {2,0,0,0,0,2,20,80,500,10000,100000},{2,0,0,0,0,1,10,50,250,1500,15000,500000},
        {4,0,0,0,0,0,5,25,150,1000,2500,25000,1000000}
    };
    do                                                                                                 // επαναληψη στην οποια μου δινει ο χρηστης ποσους αριθμους θα παιξει
    {
        printf("Epilekste posous arithmous tha paiksete apo enan mexri dwdeka");
        scanf("%d", &choice);                                                                              // θα τρεχει στο διαστημα 1 εως 12

    }
    while((choice<1) && (choice<12));
    printf("\n\n");
    for(i=0; i<choice; i++)                                                           //  εδω χρησιμοποιω την for για να μου δωσει τους αριθμους που θελει και θα τους αποθηκευσω σε εναν πινακα ακεραιων
    {
        printf("Dialekse enan arithmo apo to ena mexri to ogdonta kai panta enter");
        scanf("%d", &num);
        number[i]=num;
    }
    printf("Oi aritmoi pou dialekses einai");                                       //εμφανιζω τον πινακα με τους αρθμους του χρηστη
    for (i=0; i<choice; i++)
    {
        printf("\n");
        printf("%d", number[i]);
    }
    do
    {
        printf("\n Ta posa pou mporeis na paikseis einai 1, 2 , 5 h 10 eurw.");                           //  σχετικο μηνυμα να ενημερωσω για τα λεφτα
        printf("\n Parakalw dwse mou to poso pou theleis na paikseis");                                // εδω μου δινει ποσα λεφτα θελει να παιξει στις απαραιτητες επιλογες 1 2 5 10
        scanf("%d", &poso);

    }
    while(poso!=1 && poso!=2 && poso!=5 && poso!=10);

    for(i=0; i<20; i++)                                             //εδω με την χρηση της rand θα παρω αριθμους απο 1 εως 80
    {
        lucky_num[i]=rand() % 81;                          // τους βαζω σε πινακα για να τους κρατησω
    }
    printf("Oi 20 arithmoi pou klirothikan  einai");
    for(i=0; i<20; i++)                                        // επειτα παλι με επαναληψη τους εμφανιζω
    {
        printf("\n");
        printf("%d", lucky_num[i]);
    }
    count=0;                      //  μηδενιζω το count
    printf("\n\n");
    for(i=0; i<choice; i++)                // με τις δυο εμφολευμενες for θα καταφερω να βρω ποιοι αριθμοι στο διαστημα που εχει διαλεξει ο χρηστης ειναι ιδιοι με τους τυχαιους στο διαστημα 1 εως 20
    {
        for(j=0; j<20; j++)
        {
            if (number[i]==lucky_num[j])
            {
                count++;
            }
        }

    }
    printf("Oi arithmoi pou petixes einai %d", count);           //   εδω εμφανιζω ποσους αρθμους πετυχε
    printf("\n");
    kerdos=poso*rendition[choice][count];                                  //    με αυτη την πραξη υπολογιζω το κερδος
    printf("Ta lefta pou kerdises einai %d euro", kerdos);               //   και το εμφανιζω
    return 0;
}
