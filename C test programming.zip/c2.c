/*  Giorgos Doumouras icsd15046
    Ergasia 2, Askhsh 2
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 100
int main()
{
    int i, j;                      // δηλωνω μεταβλητες
    char com[N];            //πινακας για συμπιεσμενη μορφη κειμενου
    char dcom[N];          //    πινακας για αποσυμπιεσμενη μορφη
    for(i=0; i<N; i++)         // μηδενιζω τον πινακα διοτι ηταν γεματος με συμβολα μετα την δηλωση και δεν μπορουσε να δουλεψει το προγραμμα σωστα
    {
        dcom[i]=0;
    }
    printf("Please type your string: ");           // μου δινει ο χρηστης το κειμενο
    scanf(" %s", &com);
    printf("\n");
    printf("Your string in compressed type is %s", com);      //  του το εμφανιζω
    printf("\n");
    for (i=0; i<N; i++)
    {                                      // ο μετρητης i ειναι για τον πινακα com[N] και ο j ειναι για τον dcom[N]
        for(j=0; j<com[i]; j++)                        // εδω βλεπω μεσω του ascii αν ειναι αριθμος το κουτακι του πινακα και εμφανιζω το επομενο γραμα τοσες φορες οσες ειναι ο αριθμος
        {
            if(com[i]>=48 && com[i]<=57)
            {
                com[i+1]=dcom[j];
            }
            if((com[i]>=65 && com[i]<=90) ||(com[i]>=97 && com[i]<=122) )           //αν δεν υπαρχει αριθμος τοτε εμφανιζεται το γραμμα μια φορα
            {
                com[i]=dcom[i];
            }
        }
    }
    printf("Your string in a decompressed type is %s", dcom);      // εμφανιζω την αποσυμπιεσμενη μορφη δυστυχως ομως παρολες τις δοκιμες μου η μεταβλητη δεν εμφανιζεται ενω στο Build δεν μου δειχνει καποιο προβλημα

    return 0;
}
