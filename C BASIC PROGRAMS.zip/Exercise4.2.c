//icsd 15046 (Γιωργος Δουμουρας)
//icsd 15055(Αθανασιος Ζαρκαδας)



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

struct StudentNode *head;       //   Δηλωνουμε μεταβλητες για τις συναρτησεις και την main για να μην χρειαζεται να τα κανουμε στην πορεια
struct StudentNode *nd;
struct StudentNode *temp;        //  Αυτες ειναι για την δομη του φοιτητη
struct StudentNode *prev;


struct StudentNode        // Φτιαχνουμε την λιστα του φοιτητη
{
    char name[30];
    struct Node *next;
};

void Enqueue(struct StudentNode *nd, char n)
{
    if (head==NULL)    // Αν το πρωτο στοιχειο ειναι μηδεν προσθετουμε νεο και προχωραμε ενα κουτακι παρακατω
    {
        head=nd;
        nd->name[30]=n;
        nd->next=NULL;
    }
    else
    {
        temp=head;               //αρχικοποιουμε με το πρωτο στοιχειο της λιστας
        while (temp!=NULL)       // δουλευει μεχρι να μην ειμαστε στο τελευταιο κομβο
        {
            prev=temp;
            temp=temp->next;
            nd->next=NULL;
        }
        prev->next=nd;                 // Εδω βαζουμε στο κουτακι της λιστας το ονομα που μας δωθηκε
        nd->name[30]=n;
    }
}
void Dequeue(struct Node *nd)
{
                                         /*   Σε αυτη την συναρτηση θα διαγραφουμε το στοιχειο με τον φοιτητη
                                    NULL δηλαδη τον πρωτο.Επειδη ομως δεν θελουμε να χασουμε τα προηγουμενα στοιχεια τις λιστας μας,
                            αρχεικοποιουμε το temp και το prev καθε φορα που σβηνεται ενα στοιχειο ωστε να λειτουργει
                                        σωστα η λιστα*/

    if (head==NULL)    // Αν το πρωτο στοιχειο ειναι μηδεν
    {
        printf("There are no students in the queue.\n");
    }
    else
    {
        temp=head;

        if (temp->next==NULL)         // Εδω κοιταω στον τελευταιο φοιτητη που μας εχει απομεινει
        {
            free(temp);      // Αφαιρουμε τον φοιτητη
            head=NULL;
            printf("There was one student in the queue and is deleted.\n");
        }
        else
        {
            head=temp->next;         //       Αν υπαρχουν παραπανω απο ενας φοιτητες σβηνεται ο πρωτος
            free(temp);
            printf("There was more than one students in the queue and the first one is deleted.\n");

        }
    }

}

void displayStudents(struct StudentNode *nd)
{
    temp=head;

                       //Εκτυπωνει ολα τα στοιχεια της λιστας απο το Head μεχρι το τελος οπου ο τελευταιος pointer ειναι ΝULL
    while (temp!=NULL)
    {
        printf("%s\n",temp->name);
        temp=temp->next;
    }
    printf("\n");
}                                               //    Εδω μας βγαζει συμβολα στην εκτυπωση για καποιον λογο κατι δεν δουλευει που δεν μπορουμε να βρουμε


void countingStudent(struct Node *nd)      // Εδω μετραμε φοιτητηες
{

    int count1=0;          //κανουμε χρηση μετρητη για να μετρησουμε τους φοιτητες
    temp=head;           //ξεκιναμε με τον Head
    while (temp!=NULL)   //Μεχρι να φτασουμε στο τελευταιο που ειναι το null ανεβαζουμε τον μετρητη κατα ενα και προχωραμε ενα κουτακι παρακατω
    {
        count1++;
        temp=temp->next;
    }
    printf("The number of Students to serve is %d .\n\n", count1);          //εξοδος για τον χρηστη
}

int main()
{
    char n[30];           //  εδω για τους φοιτητες
    int option;
    do
    {
        printf("\n1)Enter new student in queue.\n");
        printf("2)Exit student from the queue.\n");
        printf("3)View details of students to serve.\n");
        printf("4)View number of students to serve.\n");
        printf("5)Exit.\n\n");

        printf("Please select an option : ");
        scanf("%d",&option);
        printf("\n");

        if(option==1)
        {
            printf("Give a name : ");               //Εισαγωγη ονοματος απο τον χρηστη
            scanf("%s",&n);
            printf("\n");
            nd=(struct StudentNode*)malloc(sizeof(struct StudentNode));        //Οριζει το πρωτο κουτακι της λιστας
            Enqueue(nd,n);//Καλει την συναρτηση 1.
        }
        else if(option==2)
        {
             Dequeue(nd);//Καλει την συναρτηση 2.
        }
        else if(option==3)
        {
                displayStudents(nd); //Καλει την 3
        }
        else if(option==4)
        {
            countingStudent(nd);//Καλει την συναρτηση 4
        }

    }
    while(option!=5);
    printf("The program has closed.");     // return 0
}
